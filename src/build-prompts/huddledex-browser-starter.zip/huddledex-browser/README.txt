HUDDLEDEX — BROWSER STARTER

A working, self-contained browser adaptation of the HuddleDex iPhone app.
This is new browser code based on the native app's models and workflows.
It is not the original development prompt, native source, or a complete port.

RUN
Open index.html in a modern browser. For consistent storage and microphone
support, serve this directory from localhost or an HTTPS static host.
If Python is installed: python3 -m http.server 8000
Then open http://localhost:8000/
No package installation, account, API key, or build step is needed.
The notebook starts empty. "Try fictional demo" adds made-up example records.

BUILD WITH AI
The accompanying huddledex-browser-build-prompt.txt includes this exact
index.html, plus instructions to write it into a runnable project and verify it.
Use a coding tool that can create files or previews. General chat interfaces
may instead return an HTML file; save it and serve it as above.
If a tool truncates a long prompt, attach this starter and ask it to use the
attached index.html. No specific AI model is guaranteed to reproduce it in one
response. The delivered starter itself has been tested, not every model's output.

NATIVE BEHAVIOR CARRIED OVER
- Events, active event selection, and unique person counts per event.
- Stable current contact profiles, with separate snapshots for every encounter.
- Explicitly choose an existing connection; same names never auto-merge.
- Editing a current profile preserves historical snapshots. An encounter editor
  has an explicit option to update the current profile as well.
- Name, role, company, email, LinkedIn, website; normalized tags; all-token,
  case/diacritic-insensitive search across contacts, snapshots, notes, tasks.
- Event/company/tag filters; repeat encounters; notes; one follow-up per encounter
  with due date and completed/reopen controls.
- Separate encounter and badge photos, resized and re-encoded as JPEG.
- Multiple audio clips, 60 seconds each, explicit permission, playback/removal.
  Unsaved clips are discarded on cancel; microphone tracks stop on close.
- Trash, restore, and confirmed permanent connection deletion.
- My card with optional photo, up to eight labeled HTTPS links, vCard download.
  The vCard contains text contact details and URLs; its photo is not embedded.
- Selective CSV/Markdown export with current and recorded contact fields.
  Notes, follow-ups, and tags are off by default. Trashed records are excluded.
- Atomic browser persistence: UI commits only after the IndexedDB transaction
  succeeds. A stale tab cannot overwrite a newer notebook revision.

BROWSER ADAPTATIONS / LIMITS
- Offline HTML event-memory sharing contains only the encounter photo and
  event name/date/venue. Native sharing uses hosted revocable links instead.
  An exported HTML file cannot be revoked.
- Browser MediaRecorder replaces native audio capture. Requires browser support
  and microphone permission. No speech service or automatic transcription.
- No badge OCR, native on-device speech transcription, maps/globe, geocoding,
  hosted profile/QR publishing, account sync, native imports, or ZIP media backup.
- CSV/Markdown export excludes photos, badges, recordings, My card and trash.
  It cannot restore the complete notebook. Download individual photos through
  your browser if you need to keep them. Do not treat this prototype as a backup.
- Browser storage is specific to its origin and profile; clearing site data,
  browser eviction or switching devices can lose access to it. Private browsing
  may discard records. There is no encryption at rest implemented by this app.
- Run on a dedicated origin for real use: unrelated scripts on the same origin
  can access its IndexedDB. This starter makes no network calls after loading
  its HTML and uses no third-party scripts, analytics, fonts, or remote media.
  Clicking links you add is an explicit navigation to those destinations.

DATA BOUNDARY
The public starter has no original notebook, real contacts, event photos,
recordings, published profile IDs, credentials, service configuration, account
identifiers, or native build output. Its demo uses fictional names and the
reserved example.invalid email domain. It never loads the owner's iPhone data.
New photos are re-encoded without file metadata; visible image content remains.
Exports intentionally contain any contact/event data you entered. Private
notes/tasks/tags require opt-in. Shared memory files use an explicit allowlist.

VERIFICATION
See VERIFICATION.txt for actual checks and untested device capabilities.
